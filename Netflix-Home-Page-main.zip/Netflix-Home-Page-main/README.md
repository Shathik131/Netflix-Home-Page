# Netflix-Home-Page
Created a Netflix home page with HTML/CSS

User-Interface:
![Screenshot from 2022-09-23 21-29-15](https://user-images.githubusercontent.com/110757279/192004584-8f78978f-ea65-47bf-974c-b173dba9548c.png)
![Screenshot from 2022-09-23 21-30-05](https://user-images.githubusercontent.com/110757279/192004592-fb150de2-d3f2-47e8-b713-0f53c353376d.png)
![Screenshot from 2022-09-23 21-33-38](https://user-images.githubusercontent.com/110757279/192004601-f5461abf-ab39-447d-9898-1b44c27891f1.png)
![Screenshot from 2022-09-23 21-34-05](https://user-images.githubusercontent.com/110757279/192004607-49382e59-7a13-4d7a-9b2a-dfe8478a9be9.png)
![Screenshot from 2022-09-23 21-34-38](https://user-images.githubusercontent.com/110757279/192004619-0908f768-b4d0-4f31-b6a8-d22c685e93e9.png)
![Screenshot from 2022-09-23 21-35-24](https://user-images.githubusercontent.com/110757279/192004634-c809bc36-ddd2-4528-b02c-c9f91815cf49.png)
![Screenshot from 2022-09-23 21-36-37](https://user-images.githubusercontent.com/110757279/192004641-b6c4f93d-8672-42c5-815c-5916cc1910d9.png)
